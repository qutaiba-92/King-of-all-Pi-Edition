import React, { CSSProperties } from "react";
import { User } from "../";

interface Props {
  onSignIn: () => void;
  onSignOut: () => void;
  onSendTestNotification: () => void;
  user: User | null;
}

const headerStyle: CSSProperties = {
  padding: 8,
  backgroundColor: "gray",
  color: "white",
  width: "100%",
  display: "flex",
  alignItems: "center",
  justifyContent: "space-between",
};

export default function Header(props: Props) {
  return (
    <header style={headerStyle}>
      <div style={{ fontWeight: "bold" }}>Pi Bakery</div>

      <div>
        {props.user === null ? (
          <button onClick={props.onSignIn}>Sign in</button>
        ) : (
          <div>
            @{props.user.username}{" "}
            <button type="button" onClick={props.onSignOut}>
              Sign out
            </button>
            {props.user.roles.includes("core_team") && (
              <button onClick={props.onSendTestNotification}>
                Send Test Notification to yourself
              </button>
            )}
          </div>
        )}
      </div>
    </header>
  );
}
